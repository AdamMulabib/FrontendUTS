import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import axios from "axios";
import { useEffect, useState } from "react";

const schema = z.object({
  name: z.string().min(3),
  category: z.string().min(1),
  dateEvent: z.string().min(1),
  location: z.string().min(3),
  description: z.string().min(5),
  pembicara: z.array(z.string()).optional(),
});

type FormData = z.infer<typeof schema>;

type Category = {
  id: string;
  name: string;
};

type Speaker = {
  id: string;
  name: string;
};

export default function EventCreate() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [speakers, setSpeakers] = useState<Speaker[]>([]);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      pembicara: [],
    },
  });

  // GET CATEGORY
  useEffect(() => {
    axios
      .get("http://localhost:3000/categories")
      .then((res) => setCategories(res.data))
      .catch(console.log);
  }, []);

  // GET SPEAKER
  useEffect(() => {
    axios
      .get("http://localhost:3000/pembicara")
      .then((res) => setSpeakers(res.data))
      .catch(console.log);
  }, []);

  const selectedSpeakers = watch("pembicara") || [];

  const toggleSpeaker = (id: string) => {
    if (selectedSpeakers.includes(id)) {
      setValue(
        "pembicara",
        selectedSpeakers.filter((x) => x !== id)
      );
    } else {
      setValue("pembicara", [...selectedSpeakers, id]);
    }
  };

  // SUBMIT
  const onSubmit = async (data: FormData) => {
    try {
      await axios.post("http://localhost:3000/events", {
        name: data.name,
        categoryId: data.category,
        dateEvent: data.dateEvent,
        location: data.location,
        description: data.description,
        pembicaraIds: data.pembicara || [],
      });

      alert("Event berhasil dibuat!");
    } catch (error) {
      console.log(error);
      alert("Gagal membuat event");
    }
  };

  return (
    <div className="max-w-xl mx-auto mt-10 p-6 border rounded-xl shadow">

      <h1 className="text-2xl font-bold mb-4">
        Tambah Event
      </h1>

      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">

        <input {...register("name")} placeholder="Nama Event" className="border p-2" />

        <select {...register("category")} className="border p-2">
          <option value="">Pilih Kategori</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>

        <input type="date" {...register("dateEvent")} className="border p-2" />

        <input {...register("location")} placeholder="Lokasi" className="border p-2" />

        <textarea {...register("description")} placeholder="Deskripsi" className="border p-2" />

        {/* SPEAKER */}
        <div className="border p-2">
          <p className="font-bold mb-2">Pilih Speaker</p>

          {speakers.map((s) => (
            <label key={s.id} className="flex gap-2">
              <input
                type="checkbox"
                checked={selectedSpeakers.includes(s.id)}
                onChange={() => toggleSpeaker(s.id)}
              />
              {s.name}
            </label>
          ))}
        </div>

        <button className="bg-red-600 text-white p-2">
          Simpan Event
        </button>

      </form>
    </div>
  );
}